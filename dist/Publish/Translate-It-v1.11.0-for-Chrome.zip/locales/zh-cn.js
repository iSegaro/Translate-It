const e="Chinese (Simplified)",i="简体中文",a="Chinese (Simplified)",m="zh-cn",n={name:e,nativeName:i,promptName:a,code:m};export{m as code,n as default,e as name,i as nativeName,a as promptName};
