const e="Chinese (Traditional)",a="繁體中文",t="Chinese (Traditional)",i="zh-tw",n={name:e,nativeName:a,promptName:t,code:i};export{i as code,n as default,e as name,a as nativeName,t as promptName};
