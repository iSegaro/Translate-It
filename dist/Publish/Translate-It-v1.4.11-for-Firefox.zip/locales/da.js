const a="Danish",e="da-DK",d="Danish",o="da",n={name:a,voiceCode:e,promptName:d,code:"da"};export{o as code,n as default,a as name,d as promptName,e as voiceCode};
