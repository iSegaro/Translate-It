const e="Russian",a="ru-RU",o="Russian",s="ru",u={name:e,voiceCode:a,promptName:o,code:"ru"};export{s as code,u as default,e as name,o as promptName,a as voiceCode};
