const a="Tagalog",o="tl-PH",e="Tagalog",t="tl",l={name:a,voiceCode:o,promptName:e,code:"tl"};export{t as code,l as default,a as name,e as promptName,o as voiceCode};
