const o="Polish",e="pl-PL",l="Polish",p="pl",a={name:o,voiceCode:e,promptName:l,code:"pl"};export{p as code,a as default,o as name,l as promptName,e as voiceCode};
