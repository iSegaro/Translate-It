const e="Swedish",s="sv-SE",o="Swedish",d="sv",a={name:e,voiceCode:s,promptName:o,code:"sv"};export{d as code,a as default,e as name,o as promptName,s as voiceCode};
