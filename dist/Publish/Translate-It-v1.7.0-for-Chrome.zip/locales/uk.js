const a="Ukrainian",e="uk-UA",n="Ukrainian",o="uk",i={name:a,voiceCode:e,promptName:n,code:"uk"};export{o as code,i as default,a as name,n as promptName,e as voiceCode};
