const o="Slovak",e="sk-SK",a="Slovak",k="sk",s={name:o,voiceCode:e,promptName:a,code:"sk"};export{k as code,s as default,o as name,a as promptName,e as voiceCode};
