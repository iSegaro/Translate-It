const o="Pashto",e="ps-AF",s="Pashto",a="ps",p={name:o,voiceCode:e,promptName:s,code:"ps"};export{a as code,p as default,o as name,s as promptName,e as voiceCode};
