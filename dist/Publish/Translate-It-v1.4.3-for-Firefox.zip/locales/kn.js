const a="Kannada",n="kn-IN",e="Kannada",o="kn",d={name:a,voiceCode:n,promptName:e,code:"kn"};export{o as code,d as default,a as name,e as promptName,n as voiceCode};
