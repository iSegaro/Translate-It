const o="Romanian",a="ro-RO",e="Romanian",n="ro",m={name:o,voiceCode:a,promptName:e,code:"ro"};export{n as code,m as default,o as name,e as promptName,a as voiceCode};
