const a="Latvian",e="lv-LV",o="Latvian",t="lv",v={name:a,voiceCode:e,promptName:o,code:"lv"};export{t as code,v as default,a as name,o as promptName,e as voiceCode};
