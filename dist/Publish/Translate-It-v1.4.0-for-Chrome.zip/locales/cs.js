const e="Czech",c="cs-CZ",o="Czech",s="cs",a={name:e,voiceCode:c,promptName:o,code:"cs"};export{s as code,a as default,e as name,o as promptName,c as voiceCode};
