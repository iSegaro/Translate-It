const i="Hindi",e="hi-IN",o="Hindi",d="hi",a={name:i,voiceCode:e,promptName:o,code:"hi"};export{d as code,a as default,i as name,o as promptName,e as voiceCode};
