const e="Vietnamese",a="vi-VN",i="Vietnamese",o="vi",t={name:e,voiceCode:a,promptName:i,code:"vi"};export{o as code,t as default,e as name,i as promptName,a as voiceCode};
