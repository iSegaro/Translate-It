const a="Malayalam",l="ml-IN",m="Malayalam",e="ml",o={name:a,voiceCode:l,promptName:m,code:"ml"};export{e as code,o as default,a as name,m as promptName,l as voiceCode};
