const e="Belarusian",a="be-BY",o="Belarusian",n="be",r={name:e,voiceCode:a,promptName:o,code:"be"};export{n as code,r as default,e as name,o as promptName,a as voiceCode};
