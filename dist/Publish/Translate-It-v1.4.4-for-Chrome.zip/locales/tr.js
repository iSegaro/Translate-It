const e="Turkish",r="tr-TR",t="Turkish",o="tr",a={name:e,voiceCode:r,promptName:t,code:"tr"};export{o as code,a as default,e as name,t as promptName,r as voiceCode};
