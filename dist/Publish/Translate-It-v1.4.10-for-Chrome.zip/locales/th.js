const e="Thai",t="th-TH",a="Thai",o="th",h={name:e,voiceCode:t,promptName:a,code:"th"};export{o as code,h as default,e as name,a as promptName,t as voiceCode};
