const e="Serbian",r="sr-RS",a="Serbian",o="sr",s={name:e,voiceCode:r,promptName:a,code:"sr"};export{o as code,s as default,e as name,a as promptName,r as voiceCode};
