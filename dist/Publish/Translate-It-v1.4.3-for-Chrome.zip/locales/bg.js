const a="Bulgarian",e="bg-BG",o="Bulgarian",g="bg",n={name:a,voiceCode:e,promptName:o,code:"bg"};export{g as code,n as default,a as name,o as promptName,e as voiceCode};
