const e="Greek",o="el-GR",a="Greek",l="el",r={name:e,voiceCode:o,promptName:a,code:"el"};export{l as code,r as default,e as name,a as promptName,o as voiceCode};
