const e="Urdu",r="ur-PK",o="Urdu",u="ur",d={name:e,voiceCode:r,promptName:o,code:"ur"};export{u as code,d as default,e as name,o as promptName,r as voiceCode};
