const e="Dutch",o="nl-NL",t="Dutch",c="nl",n={name:e,voiceCode:o,promptName:t,code:"nl"};export{c as code,n as default,e as name,t as promptName,o as voiceCode};
