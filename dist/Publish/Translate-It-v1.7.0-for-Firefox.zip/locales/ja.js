const a="Japanese",e="ja-JP",o="Japanese",p="ja",n={name:a,voiceCode:e,promptName:o,code:"ja"};export{p as code,n as default,a as name,o as promptName,e as voiceCode};
