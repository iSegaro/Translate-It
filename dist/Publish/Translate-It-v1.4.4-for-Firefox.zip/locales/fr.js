const e="French",r="fr-FR",o="French",c="fr",a={name:e,voiceCode:r,promptName:o,code:"fr"};export{c as code,a as default,e as name,o as promptName,r as voiceCode};
