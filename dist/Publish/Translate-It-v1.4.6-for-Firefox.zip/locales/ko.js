const o="Korean",e="ko-KR",a="Korean",n="ko",r={name:o,voiceCode:e,promptName:a,code:"ko"};export{n as code,r as default,o as name,a as promptName,e as voiceCode};
