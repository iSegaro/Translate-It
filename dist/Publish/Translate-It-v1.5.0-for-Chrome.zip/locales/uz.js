const e="Uzbek",o="uz-UZ",z="Uzbek",a="uz",t={name:e,voiceCode:o,promptName:z,code:"uz"};export{a as code,t as default,e as name,z as promptName,o as voiceCode};
